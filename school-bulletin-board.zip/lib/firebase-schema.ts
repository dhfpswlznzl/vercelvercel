export interface FirestoreUser {
  id: string
  name: string
  email: string
  avatar: string
  bio: string
  isAdmin: boolean
  followers: string[]
  following: string[]
  bookmarks: string[]
  createdAt: Date
  updatedAt?: Date
}

export interface FirestorePost {
  id: string
  title: string
  content: string
  authorId: string
  category: "notice" | "free" | "anonymous" | "qna" | "study"
  tags: string[]
  images: string[]
  createdAt: Date
  updatedAt?: Date
  isPinned: boolean
  isAnonymous: boolean
  isApproved: boolean
  reactions: { [emoji: string]: string[] }
  views: number
}

export interface FirestoreComment {
  id: string
  content: string
  authorId: string
  createdAt: Date
  isAnonymous: boolean
}

// Validation functions
export const validateUser = (user: Partial<FirestoreUser>): boolean => {
  return !!(user.name && user.email && typeof user.isAdmin === "boolean")
}

export const validatePost = (post: Partial<FirestorePost>): boolean => {
  return !!(
    post.title &&
    post.content &&
    post.authorId &&
    post.category &&
    ["notice", "free", "anonymous", "qna", "study"].includes(post.category)
  )
}

export const validateComment = (comment: Partial<FirestoreComment>): boolean => {
  return !!(comment.content && comment.authorId && typeof comment.isAnonymous === "boolean")
}
