import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  setDoc,
} from "firebase/firestore"
import { db } from "@/app/page"

// Collection references
export const usersCollection = collection(db, "users")
export const postsCollection = collection(db, "posts")
export const commentsCollection = collection(db, "comments")

// User operations
export const createUser = async (userData: any) => {
  try {
    return await setDoc(doc(db, "users", userData.id), {
      ...userData,
      createdAt: serverTimestamp(),
      followers: userData.followers || [],
      following: userData.following || [],
      bookmarks: userData.bookmarks || [],
    })
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}

export const getUserById = async (userId: string) => {
  try {
    const userDoc = await getDoc(doc(db, "users", userId))
    if (userDoc.exists()) {
      const data = userDoc.data()
      return {
        id: userDoc.id,
        ...data,
        createdAt: data.createdAt?.toDate() || new Date(),
      }
    }
    return null
  } catch (error) {
    console.error("Error getting user:", error)
    throw error
  }
}

export const updateUser = async (userId: string, updates: any) => {
  try {
    return await updateDoc(doc(db, "users", userId), {
      ...updates,
      updatedAt: serverTimestamp(),
    })
  } catch (error) {
    console.error("Error updating user:", error)
    throw error
  }
}

export const getAllUsers = async () => {
  try {
    const snapshot = await getDocs(usersCollection)
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    }))
  } catch (error) {
    console.error("Error getting all users:", error)
    throw error
  }
}

// Post operations
export const createPost = async (postData: any) => {
  try {
    return await addDoc(postsCollection, {
      ...postData,
      createdAt: serverTimestamp(),
      reactions: postData.reactions || {},
      views: postData.views || 0,
      isApproved: postData.category !== "anonymous" || postData.isApproved,
    })
  } catch (error) {
    console.error("Error creating post:", error)
    throw error
  }
}

export const getPosts = async () => {
  try {
    const postsQuery = query(postsCollection, orderBy("createdAt", "desc"))
    const snapshot = await getDocs(postsQuery)
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    }))
  } catch (error) {
    console.error("Error getting posts:", error)
    throw error
  }
}

export const updatePost = async (postId: string, updates: any) => {
  try {
    return await updateDoc(doc(db, "posts", postId), {
      ...updates,
      updatedAt: serverTimestamp(),
    })
  } catch (error) {
    console.error("Error updating post:", error)
    throw error
  }
}

export const deletePost = async (postId: string) => {
  try {
    return await deleteDoc(doc(db, "posts", postId))
  } catch (error) {
    console.error("Error deleting post:", error)
    throw error
  }
}

// Real-time listeners
export const subscribeToUsers = (callback: (users: any[]) => void) => {
  console.log("[v0] Setting up users real-time listener")
  return onSnapshot(
    usersCollection,
    (snapshot) => {
      console.log("[v0] Users snapshot received:", snapshot.size, "documents")
      const users = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
      }))
      callback(users)
    },
    (error) => {
      console.error("[v0] Error in users subscription:", error)
      // Attempt to reconnect after a delay
      setTimeout(() => {
        console.log("[v0] Attempting to reconnect users listener")
        subscribeToUsers(callback)
      }, 5000)
    },
  )
}

export const subscribeToPosts = (callback: (posts: any[]) => void) => {
  console.log("[v0] Setting up posts real-time listener")
  const postsQuery = query(postsCollection, orderBy("createdAt", "desc"))
  return onSnapshot(
    postsQuery,
    (snapshot) => {
      console.log("[v0] Posts snapshot received:", snapshot.size, "documents")
      const posts = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
      }))
      callback(posts)
    },
    (error) => {
      console.error("[v0] Error in posts subscription:", error)
      // Attempt to reconnect after a delay
      setTimeout(() => {
        console.log("[v0] Attempting to reconnect posts listener")
        subscribeToPosts(callback)
      }, 5000)
    },
  )
}

export const subscribeToComments = (postId: string, callback: (comments: any[]) => void) => {
  console.log("[v0] Setting up comments real-time listener for post:", postId)
  const commentsQuery = query(collection(db, "posts", postId, "comments"), orderBy("createdAt", "asc"))
  return onSnapshot(
    commentsQuery,
    (snapshot) => {
      console.log("[v0] Comments snapshot received:", snapshot.size, "documents")
      const comments = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
      }))
      callback(comments)
    },
    (error) => {
      console.error("[v0] Error in comments subscription:", error)
    },
  )
}
