"use client"

import { initializeApp } from "firebase/app"
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore"
import {
  getAuth,
  connectAuthEmulator,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type User,
} from "firebase/auth"

import { Label } from "@/components/ui/label"

import type React from "react"
import { useState, createContext, useContext, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Plus,
  MessageCircle,
  Bookmark,
  Pin,
  Users,
  Settings,
  X,
  Trash2,
  Edit,
  LogOut,
  UserMinus,
  UserPlus,
  FileText,
  BarChart3,
  CheckCircle,
  XCircle,
  ImageIcon,
  Hash,
} from "lucide-react"

const hasFirebaseConfig = !!(
  process.env.NEXT_PUBLIC_FIREBASE_API_KEY &&
  process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN &&
  process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID
)

const firebaseConfig = hasFirebaseConfig
  ? {
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
      authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
      storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
      appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
    }
  : null

let app: any = null
let db: any = null
let auth: any = null

if (hasFirebaseConfig && firebaseConfig) {
  try {
    app = initializeApp(firebaseConfig)
    db = getFirestore(app)
    auth = getAuth(app)

    // Connect to emulators in development
    if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
      try {
        connectFirestoreEmulator(db, "localhost", 8080)
        connectAuthEmulator(auth, "http://localhost:9099")
      } catch (error) {
        console.log("[v0] Firebase emulators already connected or not available")
      }
    }
  } catch (error) {
    console.error("[v0] Firebase initialization failed:", error)
  }
}

export { db, auth }

// Types
interface UserProfile {
  id: string
  name: string
  email: string
  avatar: string
  bio: string
  isAdmin: boolean
  followers: string[]
  following: string[]
  bookmarks: string[]
}

interface Post {
  id: string
  title: string
  content: string
  author: UserProfile
  category: "notice" | "free" | "anonymous" | "qna" | "study"
  tags: string[]
  images: string[]
  createdAt: Date
  isPinned: boolean
  isAnonymous: boolean
  isApproved: boolean
  reactions: { [key: string]: string[] }
  comments: Comment[]
  views: number
  hotScore?: number
}

interface Comment {
  id: string
  content: string
  author: UserProfile
  createdAt: Date
  isAnonymous: boolean
}

// Mock Data
const mockUsers: UserProfile[] = [
  {
    id: "1",
    name: "관리자",
    email: "admin@school.edu",
    avatar: "/admin-interface.png",
    bio: "학교 게시판 관리자입니다.",
    isAdmin: true,
    followers: ["2", "3"],
    following: [],
    bookmarks: ["1", "2"],
  },
  {
    id: "2",
    name: "김학생",
    email: "student1@school.edu",
    avatar: "/diverse-student-studying.png",
    bio: "컴퓨터공학과 3학년입니다.",
    isAdmin: false,
    followers: ["3"],
    following: ["1"],
    bookmarks: ["1"],
  },
  {
    id: "3",
    name: "이학생",
    email: "student2@school.edu",
    avatar: "/diverse-students-studying.png",
    bio: "경영학과 2학년입니다.",
    isAdmin: false,
    followers: [],
    following: ["1", "2"],
    bookmarks: ["2", "3"],
  },
]

const mockPosts: Post[] = [
  {
    id: "1",
    title: "2024학년도 2학기 수강신청 안내",
    content: "수강신청 일정과 주의사항을 안내드립니다. 자세한 내용은 학사공지를 확인해주세요.",
    author: mockUsers[0],
    category: "notice",
    tags: ["수강신청", "학사일정"],
    images: [],
    createdAt: new Date("2024-01-15"),
    isPinned: true,
    isAnonymous: false,
    isApproved: true,
    reactions: { "👍": ["2", "3"], "❤️": ["2"] },
    comments: [
      {
        id: "c1",
        content: "감사합니다!",
        author: mockUsers[1],
        createdAt: new Date("2024-01-15"),
        isAnonymous: false,
      },
    ],
    views: 156,
  },
  {
    id: "2",
    title: "스터디 그룹 모집합니다",
    content: "알고리즘 스터디 그룹을 모집합니다. 매주 화요일 저녁에 진행할 예정입니다.",
    author: mockUsers[1],
    category: "study",
    tags: ["알고리즘", "스터디", "모집"],
    images: [],
    createdAt: new Date("2024-01-14"),
    isPinned: false,
    isAnonymous: false,
    isApproved: true,
    reactions: { "👍": ["1", "3"], "🎉": ["3"] },
    comments: [],
    views: 89,
  },
  {
    id: "3",
    title: "익명 질문입니다",
    content: "학점 관련해서 궁금한 점이 있는데 익명으로 질문드립니다.",
    author: mockUsers[2],
    category: "anonymous",
    tags: ["질문", "학점"],
    images: [],
    createdAt: new Date("2024-01-13"),
    isPinned: false,
    isAnonymous: true,
    isApproved: false,
    reactions: { "🤔": ["1"] },
    comments: [],
    views: 45,
  },
]

// Auth Context
interface AuthContextType {
  userProfile: UserProfile | null
  login: (email: string, password: string) => Promise<void>
  signup: (email: string, password: string, name: string) => Promise<void>
  logout: () => void
  updateUserProfile: (updates: Partial<UserProfile>) => void
  isLoading: boolean
  promoteToAdmin: (userId: string) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [users, setUsers] = useState<UserProfile[]>(mockUsers)

  useEffect(() => {
    if (!auth || !hasFirebaseConfig) {
      console.log("[v0] Firebase not configured, using mock authentication")
      setIsLoading(false)
      return
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser: User | null) => {
      setIsLoading(true)

      if (firebaseUser) {
        // User is signed in, fetch their profile from Firestore
        try {
          const { getUserById } = await import("@/lib/firebase")
          let userProfile = await getUserById(firebaseUser.uid)

          if (!userProfile) {
            // Create user profile if it doesn't exist
            const newProfile: UserProfile = {
              id: firebaseUser.uid,
              name: firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "User",
              email: firebaseUser.email || "",
              avatar: firebaseUser.photoURL || "/diverse-students-studying.png",
              bio: "",
              isAdmin: firebaseUser.email === "admin@school.edu",
              followers: [],
              following: [],
              bookmarks: [],
            }

            const { createUser } = await import("@/lib/firebase")
            await createUser(newProfile)
            userProfile = newProfile
          }

          setUserProfile(userProfile)
        } catch (error) {
          console.error("Error fetching user profile:", error)
        }
      } else {
        // User is signed out
        setUserProfile(null)
      }

      setIsLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const login = async (email: string, password: string) => {
    setIsLoading(true)
    try {
      if (auth && hasFirebaseConfig) {
        await signInWithEmailAndPassword(auth, email, password)
      } else {
        // Mock authentication fallback
        const user = mockUsers.find((u) => u.email === email)
        if (user) {
          setUserProfile(user)
        } else {
          throw new Error("사용자를 찾을 수 없습니다.")
        }
      }
    } catch (error: any) {
      if (error.code === "auth/user-not-found") {
        throw new Error("사용자를 찾을 수 없습니다.")
      } else if (error.code === "auth/wrong-password") {
        throw new Error("비밀번호가 올바르지 않습니다.")
      } else if (error.code === "auth/invalid-email") {
        throw new Error("유효하지 않은 이메일 주소입니다.")
      } else {
        throw new Error(error.message || "로그인 중 오류가 발생했습니다.")
      }
    } finally {
      setIsLoading(false)
    }
  }

  const signup = async (email: string, password: string, name: string) => {
    setIsLoading(true)
    try {
      if (auth && hasFirebaseConfig) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password)

        const newProfile: UserProfile = {
          id: userCredential.user.uid,
          name,
          email,
          avatar: "/diverse-students-studying.png",
          bio: "",
          isAdmin: email === "admin@school.edu",
          followers: [],
          following: [],
          bookmarks: [],
        }

        const { createUser } = await import("@/lib/firebase")
        await createUser(newProfile)
      } else {
        // Mock authentication fallback
        const existingUser = mockUsers.find((u) => u.email === email)
        if (existingUser) {
          throw new Error("이미 사용 중인 이메일 주소입니다.")
        }

        const newProfile: UserProfile = {
          id: Date.now().toString(),
          name,
          email,
          avatar: "/diverse-students-studying.png",
          bio: "",
          isAdmin: email === "admin@school.edu",
          followers: [],
          following: [],
          bookmarks: [],
        }

        setUsers((prev) => [...prev, newProfile])
        setUserProfile(newProfile)
      }
    } catch (error: any) {
      if (error.code === "auth/email-already-in-use") {
        throw new Error("이미 사용 중인 이메일 주소입니다.")
      } else if (error.code === "auth/weak-password") {
        throw new Error("비밀번호는 최소 6자 이상이어야 합니다.")
      } else if (error.code === "auth/invalid-email") {
        throw new Error("유효하지 않은 이메일 주소입니다.")
      } else {
        throw new Error(error.message || "회원가입 중 오류가 발생했습니다.")
      }
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      if (auth && hasFirebaseConfig) {
        await signOut(auth)
      } else {
        setUserProfile(null)
      }
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (userProfile) {
      const updatedProfile = { ...userProfile, ...updates }
      setUserProfile(updatedProfile)

      try {
        const { updateUser } = await import("@/lib/firebase")
        await updateUser(userProfile.id, updates)
      } catch (error) {
        console.error("Error updating user profile:", error)
      }
    }
  }

  const promoteToAdmin = async (userId: string) => {
    try {
      const { updateUser } = await import("@/lib/firebase")
      await updateUser(userId, { isAdmin: true })

      if (userProfile?.id === userId) {
        setUserProfile({ ...userProfile, isAdmin: true })
      }
    } catch (error) {
      console.error("Error promoting user to admin:", error)
    }
  }

  return (
    <AuthContext.Provider value={{ userProfile, login, signup, logout, updateUserProfile, isLoading, promoteToAdmin }}>
      {children}
    </AuthContext.Provider>
  )
}

// Login Dialog Component
const LoginDialog: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [isSignupMode, setIsSignupMode] = useState(false)
  const [error, setError] = useState("")
  const { login, signup, isLoading } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    try {
      if (isSignupMode) {
        await signup(email, password, name)
      } else {
        await login(email, password)
      }
      onClose()
      setEmail("")
      setPassword("")
      setName("")
      setIsSignupMode(false)
    } catch (err) {
      setError(err instanceof Error ? err.message : "오류가 발생했습니다.")
    }
  }

  const switchMode = () => {
    setIsSignupMode(!isSignupMode)
    setError("")
    setEmail("")
    setPassword("")
    setName("")
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button>로그인</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isSignupMode ? "회원가입" : "로그인"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignupMode && (
            <div>
              <Label htmlFor="name">이름</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="홍길동"
                required
              />
            </div>
          )}
          <div>
            <Label htmlFor="email">이메일</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={isSignupMode ? "your@email.com" : "admin@school.edu"}
              required
            />
          </div>
          <div>
            <Label htmlFor="password">비밀번호</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <div className="text-red-500 text-sm">{error}</div>}
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (isSignupMode ? "가입 중..." : "로그인 중...") : isSignupMode ? "회원가입" : "로그인"}
          </Button>
          <div className="text-center">
            <Button type="button" variant="link" onClick={switchMode}>
              {isSignupMode ? "이미 계정이 있으신가요? 로그인" : "계정이 없으신가요? 회원가입"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// Write Post Dialog Component
const WritePostDialog = ({ onPostCreated }: { onPostCreated: (post: Post) => void }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [category, setCategory] = useState<Post["category"]>("free")
  const [tags, setTags] = useState("")
  const [images, setImages] = useState<string[]>([])
  const [isAnonymous, setIsAnonymous] = useState(false)
  const { userProfile } = useAuth()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!userProfile) return

    const newPost: Post = {
      id: Date.now().toString(),
      title,
      content,
      author: isAnonymous
        ? {
            id: "anonymous",
            name: "익명",
            email: "anonymous@anonymous.com",
            avatar: "/anonymous-figure.png",
            bio: "",
            isAdmin: false,
            followers: [],
            following: [],
            bookmarks: [],
          }
        : userProfile,
      category,
      tags: tags.split(/[,\s]+/).filter((tag) => tag.trim()),
      images,
      createdAt: new Date(),
      isPinned: false,
      isAnonymous: isAnonymous,
      isApproved: !isAnonymous || userProfile.isAdmin,
      reactions: {},
      comments: [],
      views: 0,
    }

    onPostCreated(newPost)
    setIsOpen(false)
    setTitle("")
    setContent("")
    setCategory("free")
    setTags("")
    setIsAnonymous(false)

    setImages([])
    setIsAnonymous(false)
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setImages((prev) => [...prev, ...newImages])
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const files = e.dataTransfer.files
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setImages((prev) => [...prev, ...newImages])
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          글쓰기
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>새 글 작성</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-medium">
              제목
            </Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="게시글의 제목을 입력하세요"
              className="w-full"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content" className="text-sm font-medium">
              내용
            </Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="내용을 입력하세요..."
              rows={8}
              className="w-full resize-none"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags" className="text-sm font-medium flex items-center gap-1">
              <Hash className="w-4 h-4" />
              태그
            </Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="태그 입력 후 Enter..."
              className="w-full"
            />
            <p className="text-xs text-gray-500">태그를 입력하고 Enter 또는 쉼표(,)를 눌러 추가하세요.</p>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">카테고리</Label>
            <div className="flex items-center gap-4">
              <Select value={category} onValueChange={(value: Post["category"]) => setCategory(value)}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="notice">공지사항</SelectItem>
                  <SelectItem value="free">자유게시판</SelectItem>
                  <SelectItem value="anonymous">익명게시판</SelectItem>
                  <SelectItem value="qna">질문답변</SelectItem>
                  <SelectItem value="study">스터디</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="anonymous"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="w-4 h-4 rounded border border-gray-300 focus:ring-2 focus:ring-blue-500"
                />
                <Label htmlFor="anonymous" className="text-sm">
                  익명으로 작성
                </Label>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">사진 첨부</Label>
            <div
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
            >
              <div className="flex flex-col items-center gap-2">
                <ImageIcon className="w-12 h-12 text-gray-400" />
                <p className="text-sm text-gray-600">클릭하여 이미지를 업로드하세요</p>
                <p className="text-xs text-gray-500">(PNG, JPG, GIF 등)</p>
                <Input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <Label
                  htmlFor="image-upload"
                  className="cursor-pointer bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded-md text-sm transition-colors"
                >
                  파일 선택
                </Label>
              </div>
            </div>
            {images.length > 0 && (
              <div className="flex gap-2 mt-4 flex-wrap">
                {images.map((img, index) => (
                  <div key={index} className="relative">
                    <img
                      src={img || "/placeholder.svg"}
                      alt={`Upload ${index}`}
                      className="w-20 h-20 object-cover rounded border"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0"
                      onClick={() => setImages((prev) => prev.filter((_, i) => i !== index))}
                    >
                      ×
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
              취소
            </Button>
            <Button type="submit" className="bg-black text-white hover:bg-gray-800">
              작성하기
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// Post Card Component
const PostCard = ({
  post,
  onReaction,
  onComment,
  onBookmark,
  onPin,
  onDelete,
}: {
  post: Post
  onReaction: (postId: string, reaction: string) => void
  onComment: (postId: string, content: string) => void
  onBookmark: (postId: string) => void
  onPin: (postId: string) => void
  onDelete: (postId: string) => void
}) => {
  const [showComments, setShowComments] = useState(false)
  const [commentContent, setCommentContent] = useState("")
  const { userProfile } = useAuth()

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault()
    if (commentContent.trim()) {
      onComment(post.id, commentContent)
      setCommentContent("")
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "notice":
        return "bg-red-100 text-red-800"
      case "free":
        return "bg-blue-100 text-blue-800"
      case "anonymous":
        return "bg-gray-100 text-gray-800"
      case "qna":
        return "bg-green-100 text-green-800"
      case "study":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const reactionEmojis = ["👍", "❤️", "🎉", "🤔"]

  return (
    <Card className={`mb-4 ${post.isPinned ? "border-yellow-400 bg-yellow-50" : ""}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            {post.isPinned && <Pin className="w-4 h-4 text-yellow-600" />}
            <Avatar className="w-8 h-8">
              <AvatarImage
                src={post.isAnonymous ? "/placeholder.svg?height=32&width=32&query=anonymous" : post.author.avatar}
              />
              <AvatarFallback>{post.isAnonymous ? "익명" : post.author.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{post.isAnonymous ? "익명" : post.author.name}</p>
              <p className="text-xs text-gray-500">{formatTimeAgo(post.createdAt)}</p>
            </div>
            <Badge className={getCategoryColor(post.category)}>
              {post.category === "notice" && "공지"}
              {post.category === "free" && "자유"}
              {post.category === "anonymous" && "익명"}
              {post.category === "qna" && "Q&A"}
              {post.category === "study" && "스터디"}
            </Badge>
            {!post.isApproved && (
              <Badge variant="outline" className="text-orange-600 border-orange-600">
                승인대기
              </Badge>
            )}
          </div>

          {userProfile && (userProfile.isAdmin || userProfile.id === post.author.id) && (
            <div className="flex gap-1">
              {userProfile.isAdmin && (
                <Button variant="ghost" size="sm" onClick={() => onPin(post.id)}>
                  <Pin className="w-4 h-4" />
                </Button>
              )}
              <Button variant="ghost" size="sm" onClick={() => onDelete(post.id)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        <CardTitle className="text-lg">{post.title}</CardTitle>
      </CardHeader>

      <CardContent>
        <p className="text-gray-700 mb-3">{post.content}</p>

        {post.images.length > 0 && (
          <div className="grid grid-cols-2 gap-2 mb-3">
            {post.images.map((img, index) => (
              <img
                key={index}
                src={img || "/placeholder.svg"}
                alt={`Post image ${index}`}
                className="rounded-lg object-cover h-32 w-full"
              />
            ))}
          </div>
        )}

        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {post.tags.map((tag, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                #{tag}
              </Badge>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between pt-3 border-t">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              {reactionEmojis.map((emoji) => (
                <Button
                  key={emoji}
                  variant="ghost"
                  size="sm"
                  onClick={() => onReaction(post.id, emoji)}
                  className="p-1 h-auto"
                >
                  <span className="text-lg">{emoji}</span>
                  <span className="text-xs ml-1">{post.reactions[emoji]?.length || 0}</span>
                </Button>
              ))}
            </div>

            <Button variant="ghost" size="sm" onClick={() => setShowComments(!showComments)}>
              <MessageCircle className="w-4 h-4 mr-1" />
              {post.comments.length}
            </Button>

            <Button variant="ghost" size="sm" onClick={() => onBookmark(post.id)}>
              <Bookmark className={`w-4 h-4 ${userProfile?.bookmarks.includes(post.id) ? "fill-current" : ""}`} />
            </Button>
          </div>

          <span className="text-xs text-gray-500">조회 {post.views}</span>
        </div>

        {showComments && (
          <div className="mt-4 pt-4 border-t">
            {post.comments.map((comment) => (
              <div key={comment.id} className="flex gap-3 mb-3">
                <Avatar className="w-6 h-6">
                  <AvatarImage
                    src={
                      comment.isAnonymous
                        ? "/placeholder.svg?height=24&width=24&query=anonymous"
                        : comment.author.avatar
                    }
                  />
                  <AvatarFallback className="text-xs">
                    {comment.isAnonymous ? "익명" : comment.author.name[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{comment.isAnonymous ? "익명" : comment.author.name}</span>
                    <span className="text-xs text-gray-500">{formatTimeAgo(comment.createdAt)}</span>
                  </div>
                  <p className="text-sm text-gray-700">{comment.content}</p>
                </div>
              </div>
            ))}

            {userProfile && (
              <form onSubmit={handleComment} className="flex gap-2 mt-3">
                <Input
                  value={commentContent}
                  onChange={(e) => setCommentContent(e.target.value)}
                  placeholder="댓글을 입력하세요..."
                  className="flex-1"
                />
                <Button type="submit" size="sm">
                  댓글
                </Button>
              </form>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// User Profile Dialog Component
const UserProfileDialog = ({ posts, isOpen, onClose }: { posts: Post[]; isOpen: boolean; onClose: () => void }) => {
  const { userProfile, updateUserProfile, logout } = useAuth()
  const [activeTab, setActiveTab] = useState("profile")
  const [editMode, setEditMode] = useState(false)
  const [editName, setEditName] = useState("")
  const [editBio, setEditBio] = useState("")

  useEffect(() => {
    if (userProfile) {
      setEditName(userProfile.name)
      setEditBio(userProfile.bio)
    }
  }, [userProfile])

  const handleSaveProfile = () => {
    updateUserProfile({ name: editName, bio: editBio })
    setEditMode(false)
  }

  const handleFollow = (userId: string) => {
    if (!userProfile) return

    const isFollowing = userProfile.following.includes(userId)
    const newFollowing = isFollowing
      ? userProfile.following.filter((id) => id !== userId)
      : [...userProfile.following, userId]

    updateUserProfile({ following: newFollowing })
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }

  if (!userProfile) return null

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>프로필</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">프로필</TabsTrigger>
            <TabsTrigger value="posts">내 글</TabsTrigger>
            <TabsTrigger value="followers">팔로워</TabsTrigger>
            <TabsTrigger value="following">팔로잉</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <div className="flex items-center gap-4">
              <Avatar className="w-20 h-20">
                <AvatarImage src={userProfile.avatar || "/placeholder.svg"} />
                <AvatarFallback className="text-2xl">{userProfile.name[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                {editMode ? (
                  <div className="space-y-2">
                    <Input value={editName} onChange={(e) => setEditName(e.target.value)} placeholder="이름" />
                    <Textarea
                      value={editBio}
                      onChange={(e) => setEditBio(e.target.value)}
                      placeholder="자기소개"
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveProfile}>
                        저장
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditMode(false)}>
                        취소
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-xl font-semibold">{userProfile.name}</h3>
                    <p className="text-gray-600">{userProfile.bio}</p>
                    <div className="flex gap-4 mt-2 text-sm text-gray-500">
                      <span>팔로워 {userProfile.followers.length}</span>
                      <span>팔로잉 {userProfile.following.length}</span>
                      <span>북마크 {userProfile.bookmarks.length}</span>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button size="sm" onClick={() => setEditMode(true)}>
                        <Edit className="w-4 h-4 mr-1" />
                        편집
                      </Button>
                      <Button size="sm" variant="outline" onClick={logout}>
                        <LogOut className="w-4 h-4 mr-1" />
                        로그아웃
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {userProfile.bookmarks.length > 0 && (
              <div className="mt-6">
                <h4 className="font-semibold mb-3">북마크한 게시글</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {posts
                    .filter((post) => userProfile.bookmarks.includes(post.id))
                    .map((post) => (
                      <div key={post.id} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{post.title}</p>
                          <p className="text-xs text-gray-500">
                            {post.author.name} · {formatTimeAgo(post.createdAt)}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            const newBookmarks = userProfile.bookmarks.filter((id) => id !== post.id)
                            updateUserProfile({ bookmarks: newBookmarks })
                          }}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="posts">
            <div className="space-y-2">
              <h4 className="font-medium">내가 작성한 글</h4>
              {mockPosts
                .filter((post) => post.author.id === userProfile.id)
                .map((post) => (
                  <div key={post.id} className="p-3 border rounded-lg">
                    <h5 className="font-medium">{post.title}</h5>
                    <p className="text-sm text-gray-600 mt-1">{post.content.substring(0, 100)}...</p>
                  </div>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="followers">
            <div className="space-y-2">
              <h4 className="font-medium">팔로워</h4>
              {mockUsers
                .filter((user) => userProfile.followers.includes(user.id))
                .map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-2 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={user.avatar || "/placeholder.svg"} />
                        <AvatarFallback>{user.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-gray-600">{user.bio}</p>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="following">
            <div className="space-y-2">
              <h4 className="font-medium">팔로잉</h4>
              {mockUsers
                .filter((user) => userProfile.following.includes(user.id))
                .map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-2 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={user.avatar || "/placeholder.svg"} />
                        <AvatarFallback>{user.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-gray-600">{user.bio}</p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={userProfile.following.includes(user.id) ? "outline" : "default"}
                      onClick={() => handleFollow(user.id)}
                    >
                      {userProfile.following.includes(user.id) ? (
                        <>
                          <UserMinus className="w-4 h-4 mr-1" />
                          언팔로우
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-4 h-4 mr-1" />
                          팔로우
                        </>
                      )}
                    </Button>
                  </div>
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

// Admin Dashboard Component
const AdminDashboard = ({
  posts,
  onApprovePost,
  onRejectPost,
}: {
  posts: Post[]
  onApprovePost: (postId: string) => void
  onRejectPost: (postId: string) => void
}) => {
  const { promoteToAdmin } = useAuth()
  const [users] = useState<UserProfile[]>(mockUsers)

  const pendingPosts = posts.filter((post) => !post.isApproved)
  const totalPosts = posts.length
  const totalComments = posts.reduce((sum, post) => sum + post.comments.length, 0)
  const totalViews = posts.reduce((sum, post) => sum + post.views, 0)

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">관리자 대시보드</h2>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">총 게시글</p>
                <p className="text-2xl font-bold">{totalPosts}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">총 댓글</p>
                <p className="text-2xl font-bold">{totalComments}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">총 조회수</p>
                <p className="text-2xl font-bold">{totalViews}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">총 사용자</p>
                <p className="text-2xl font-bold">{mockUsers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Posts */}
      <Card>
        <CardHeader>
          <CardTitle>승인 대기 중인 게시글</CardTitle>
        </CardHeader>
        <CardContent>
          {pendingPosts.length === 0 ? (
            <p className="text-gray-500">승인 대기 중인 게시글이 없습니다.</p>
          ) : (
            <div className="space-y-4">
              {pendingPosts.map((post) => (
                <div key={post.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium">{post.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{post.content}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-gray-100 text-gray-800">익명</Badge>
                        {post.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button
                        size="sm"
                        onClick={() => onApprovePost(post.id)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        승인
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onRejectPost(post.id)}
                        className="text-red-600 border-red-600 hover:bg-red-50"
                      >
                        <XCircle className="w-4 h-4 mr-1" />
                        거부
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* User Management */}
      <Card>
        <CardHeader>
          <CardTitle>사용자 관리</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users
              .filter((user) => !user.isAdmin)
              .map((user) => (
                <div key={user.id} className="flex items-center justify-between p-3 border rounded">
                  <div className="flex items-center gap-3">
                    <img src={user.avatar || "/placeholder.svg"} alt={user.name} className="w-8 h-8 rounded-full" />
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-600">{user.email}</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => promoteToAdmin(user.id)}>
                    관리자 권한 부여
                  </Button>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

const SchoolBulletinBoard = () => {
  const [posts, setPosts] = useState<Post[]>([])
  const [users, setUsers] = useState<UserProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [currentPage, setCurrentPage] = useState<"dashboard" | "hot" | "bookmarks" | "admin">("dashboard")
  const [isLoginDialogOpen, setIsLoginDialogOpen] = useState(false)
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const { userProfile, logout } = useAuth()

  useEffect(() => {
    let unsubscribePosts: (() => void) | null = null
    let unsubscribeUsers: (() => void) | null = null

    const setupRealtimeListeners = async () => {
      try {
        setLoading(true)
        const { subscribeToPosts, subscribeToUsers } = await import("@/lib/firebase")

        // Set up real-time listener for users
        unsubscribeUsers = subscribeToUsers((firestoreUsers: any[]) => {
          console.log("[v0] Users updated:", firestoreUsers.length)
          setUsers(firestoreUsers)
        })

        // Set up real-time listener for posts
        unsubscribePosts = subscribeToPosts((firestorePosts: any[]) => {
          console.log("[v0] Posts updated:", firestorePosts.length)

          // Convert Firestore posts to include author objects
          const postsWithAuthors = firestorePosts.map((post: any) => {
            const author = users.find((user: any) => user.id === post.authorId) || {
              id: post.authorId,
              name: post.isAnonymous ? "익명" : "Unknown User",
              email: "",
              avatar: post.isAnonymous ? "/anonymous-figure.png" : "/placeholder.svg",
              bio: "",
              isAdmin: false,
              followers: [],
              following: [],
              bookmarks: [],
            }

            return {
              ...post,
              author,
              comments: [], // Comments will be loaded separately when needed
            }
          })

          setPosts(postsWithAuthors)
        })

        setLoading(false)
      } catch (error) {
        console.error("Error setting up real-time listeners:", error)
        // Fallback to mock data if Firestore fails
        setPosts(mockPosts)
        setUsers(mockUsers)
        setLoading(false)
      }
    }

    setupRealtimeListeners()

    // Cleanup listeners on component unmount
    return () => {
      if (unsubscribePosts) {
        console.log("[v0] Cleaning up posts listener")
        unsubscribePosts()
      }
      if (unsubscribeUsers) {
        console.log("[v0] Cleaning up users listener")
        unsubscribeUsers()
      }
    }
  }, [])

  useEffect(() => {
    if (users.length > 0 && posts.length > 0) {
      console.log("[v0] Updating post authors with latest user data")
      const updatedPosts = posts.map((post) => {
        const author = users.find((user) => user.id === post.author.id) || post.author
        return {
          ...post,
          author,
        }
      })
      setPosts(updatedPosts)
    }
  }, [users])

  const filteredPosts = posts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.author.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = selectedCategory === "all" || post.category === selectedCategory

    return matchesSearch && matchesCategory && post.isApproved
  })

  const getHotPosts = () => {
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    return posts
      .filter((post) => post.createdAt >= sevenDaysAgo && post.isApproved)
      .map((post) => {
        const totalReactions = Object.values(post.reactions).reduce((sum, users) => sum + users.length, 0)
        const hotScore = totalReactions * 2 + post.views // reactions worth 2x views
        return { ...post, hotScore }
      })
      .sort((a, b) => b.hotScore - a.hotScore)
      .slice(0, 20) // Top 20 hot posts
  }

  const getBookmarkedPosts = () => {
    if (!userProfile) return []
    return posts.filter((post) => userProfile.bookmarks.includes(post.id))
  }

  const handlePostCreated = async (newPost: Post) => {
    try {
      const { createPost } = await import("@/lib/firebase")

      const postData = {
        title: newPost.title,
        content: newPost.content,
        authorId: newPost.author.id,
        category: newPost.category,
        tags: newPost.tags,
        images: newPost.images,
        isPinned: newPost.isPinned,
        isAnonymous: newPost.isAnonymous,
        isApproved: newPost.isApproved,
        reactions: newPost.reactions,
        views: newPost.views,
      }

      await createPost(postData)
      console.log("[v0] Post created, real-time listener will update UI")
    } catch (error) {
      console.error("Error creating post:", error)
      // Fallback to local state update if Firestore fails
      setPosts((prev) => [newPost, ...prev])
    }
  }

  const handleReaction = async (postId: string, reaction: string) => {
    if (!userProfile) return

    try {
      const post = posts.find((p) => p.id === postId)
      if (!post) return

      const currentReactions = post.reactions[reaction] || []
      const hasReacted = currentReactions.includes(userProfile.id)

      const newReactions = {
        ...post.reactions,
        [reaction]: hasReacted
          ? currentReactions.filter((id) => id !== userProfile.id)
          : [...currentReactions, userProfile.id],
      }

      const { updatePost } = await import("@/lib/firebase")
      await updatePost(postId, { reactions: newReactions })

      console.log("[v0] Reaction updated, real-time listener will update UI")
    } catch (error) {
      console.error("Error updating reaction:", error)
      // Fallback to local state update if Firestore fails
      setPosts((prev) =>
        prev.map((post) => {
          if (post.id === postId) {
            const currentReactions = post.reactions[reaction] || []
            const hasReacted = currentReactions.includes(userProfile.id)
            return {
              ...post,
              reactions: {
                ...post.reactions,
                [reaction]: hasReacted
                  ? currentReactions.filter((id) => id !== userProfile.id)
                  : [...currentReactions, userProfile.id],
              },
            }
          }
          return post
        }),
      )
    }
  }

  const handleComment = async (postId: string, content: string) => {
    if (!userProfile) return

    try {
      const { addDoc, collection, db } = await import("firebase/firestore")

      const newComment = {
        content,
        authorId: userProfile.id,
        isAnonymous: false,
        createdAt: new Date(),
      }

      // Add comment to Firestore subcollection
      await addDoc(collection(db, "posts", postId, "comments"), newComment)

      console.log("[v0] Comment added, real-time listener will update UI")
    } catch (error) {
      console.error("Error adding comment:", error)
      // Fallback to local state update if Firestore fails
      const commentWithAuthor: Comment = {
        id: Date.now().toString(),
        content,
        author: userProfile,
        createdAt: new Date(),
        isAnonymous: false,
      }

      setPosts((prev) =>
        prev.map((post) => {
          if (post.id === postId) {
            return {
              ...post,
              comments: [...post.comments, commentWithAuthor],
            }
          }
          return post
        }),
      )
    }
  }

  const handleBookmark = async (postId: string) => {
    if (!userProfile) return

    try {
      const isBookmarked = userProfile.bookmarks.includes(postId)
      const newBookmarks = isBookmarked
        ? userProfile.bookmarks.filter((id) => id !== postId)
        : [...userProfile.bookmarks, postId]

      const { updateUser } = await import("@/lib/firebase")
      await updateUser(userProfile.id, { bookmarks: newBookmarks })

      console.log("[v0] Bookmark updated, real-time listener will update UI")
    } catch (error) {
      console.error("Error updating bookmark:", error)
    }
  }

  const handlePin = async (postId: string) => {
    try {
      const post = posts.find((p) => p.id === postId)
      if (!post) return

      const newPinnedState = !post.isPinned

      const { updatePost } = await import("@/lib/firebase")
      await updatePost(postId, { isPinned: newPinnedState })

      console.log("[v0] Pin status updated, real-time listener will update UI")
    } catch (error) {
      console.error("Error updating pin status:", error)
      // Fallback to local state update if Firestore fails
      setPosts((prev) =>
        prev.map((post) => {
          if (post.id === postId) {
            return { ...post, isPinned: !post.isPinned }
          }
          return post
        }),
      )
    }
  }

  const handleDelete = async (postId: string) => {
    try {
      const { deletePost } = await import("@/lib/firebase")
      await deletePost(postId)

      console.log("[v0] Post deleted, real-time listener will update UI")
    } catch (error) {
      console.error("Error deleting post:", error)
      // Fallback to local state update if Firestore fails
      setPosts((prev) => prev.filter((post) => post.id !== postId))
    }
  }

  const handleApprovePost = async (postId: string) => {
    try {
      const { updatePost } = await import("@/lib/firebase")
      await updatePost(postId, { isApproved: true })

      console.log("[v0] Post approved, real-time listener will update UI")
    } catch (error) {
      console.error("Error approving post:", error)
      // Fallback to local state update if Firestore fails
      setPosts((prev) =>
        prev.map((post) => {
          if (post.id === postId) {
            return { ...post, isApproved: true }
          }
          return post
        }),
      )
    }
  }

  const handleRejectPost = async (postId: string) => {
    try {
      const { deletePost } = await import("@/lib/firebase")
      await deletePost(postId)

      console.log("[v0] Post rejected, real-time listener will update UI")
    } catch (error) {
      console.error("Error rejecting post:", error)
      // Fallback to local state update if Firestore fails
      setPosts((prev) => prev.filter((post) => post.id !== postId))
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black mx-auto mb-4"></div>
          <p className="text-gray-600">게시판을 불러오는 중...</p>
        </div>
      </div>
    )
  }

  const NavigationSidebar = () => (
    <div className="w-64 bg-white border-r border-gray-200 h-screen fixed left-0 top-0 p-4">
      <div className="mb-8 flex justify-between items-center">
        <h1 className="text-xl font-bold text-gray-900">학교 게시판</h1>
        {!userProfile ? (
          <Button
            onClick={() => setIsLoginDialogOpen(true)}
            size="sm"
            className="bg-black text-white hover:bg-gray-800"
          >
            로그인
          </Button>
        ) : (
          <Button
            onClick={logout}
            size="sm"
            variant="outline"
            className="text-gray-600 hover:text-black bg-transparent"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        )}
      </div>

      <nav className="space-y-2">
        {[
          { id: "dashboard", label: "메인 대시보드", icon: "🏠" },
          { id: "hot", label: "HOT 게시물", icon: "🔥" },
          { id: "bookmarks", label: "북마크", icon: "📖" },
          ...(userProfile?.isAdmin ? [{ id: "admin", label: "관리자", icon: "⚙️" }] : []),
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentPage(item.id as any)}
            className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ease-in-out hover:bg-gray-100 hover:scale-105 ${
              currentPage === item.id ? "bg-black text-white shadow-md" : "text-gray-700 hover:text-black"
            }`}
          >
            <span className="mr-3">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      {userProfile && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <Avatar className="w-8 h-8">
              <AvatarImage src={userProfile.avatar || "/placeholder.svg"} />
              <AvatarFallback>{userProfile.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{userProfile.name}</p>
              <p className="text-xs text-gray-500 truncate">{userProfile.email}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  const renderPageContent = () => {
    switch (currentPage) {
      case "dashboard":
        return (
          <div className="space-y-6 animate-in fade-in-50 slide-in-from-bottom-4 duration-300">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">메인 대시보드</h2>
              <div className="flex gap-2">
                {userProfile && <WritePostDialog onPostCreated={handlePostCreated} />}
                {userProfile && (
                  <Button variant="ghost" className="flex items-center gap-2" onClick={() => setIsProfileOpen(true)}>
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={userProfile.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-2xl">{userProfile.name[0]}</AvatarFallback>
                    </Avatar>
                    {userProfile.name}
                  </Button>
                )}
              </div>
            </div>

            <div className="flex gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="제목, 내용, 작성자, 태그로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="카테고리 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체</SelectItem>
                  <SelectItem value="notice">📢 공지사항</SelectItem>
                  <SelectItem value="free">💬 자유게시판</SelectItem>
                  <SelectItem value="anonymous">🤫 익명게시판</SelectItem>
                  <SelectItem value="qna">❓ 학습 질문</SelectItem>
                  <SelectItem value="study">🔥 스터디 모집</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4">
              {filteredPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onReaction={handleReaction}
                  onComment={handleComment}
                  onBookmark={handleBookmark}
                  onPin={handlePin}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </div>
        )

      case "hot":
        const hotPosts = getHotPosts()
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-8 h-8 text-red-600" />
              <div>
                <h2 className="text-2xl font-bold">HOT 게시물</h2>
                <p className="text-gray-600">최근 7일간 인기 게시물 (반응 + 조회수 기준)</p>
              </div>
            </div>

            {hotPosts.length === 0 ? (
              <div className="text-center py-12">
                <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">아직 인기 게시물이 없습니다.</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {hotPosts.map((post, index) => (
                  <div key={post.id} className="relative">
                    <div className="absolute -left-4 top-4 bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold z-10">
                      {index + 1}
                    </div>
                    <PostCard
                      post={post}
                      onReaction={handleReaction}
                      onComment={handleComment}
                      onBookmark={handleBookmark}
                      onPin={handlePin}
                      onDelete={handleDelete}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        )

      case "bookmarks":
        const bookmarkedPosts = getBookmarkedPosts()
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <Bookmark className="w-8 h-8 text-yellow-600" />
              <div>
                <h2 className="text-2xl font-bold">북마크</h2>
                <p className="text-gray-600">저장한 게시물 모음</p>
              </div>
            </div>

            {!userProfile ? (
              <div className="text-center py-12">
                <Bookmark className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">북마크를 보려면 로그인하세요.</p>
                <LoginDialog isOpen={false} onClose={() => {}} />
              </div>
            ) : bookmarkedPosts.length === 0 ? (
              <div className="text-center py-12">
                <Bookmark className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">아직 북마크한 게시물이 없습니다.</p>
                <p className="text-sm text-gray-400">게시물의 북마크 버튼을 클릭해보세요!</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {bookmarkedPosts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    onReaction={handleReaction}
                    onComment={handleComment}
                    onBookmark={handleBookmark}
                    onPin={handlePin}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            )}
          </div>
        )

      case "admin":
        return userProfile?.isAdmin ? (
          <AdminDashboard posts={posts} onApprovePost={handleApprovePost} onRejectPost={handleRejectPost} />
        ) : (
          <div className="text-center py-12">
            <Settings className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">관리자 권한이 필요합니다.</p>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationSidebar />
      <div className="ml-64 p-6">
        <div className="max-w-4xl mx-auto">{renderPageContent()}</div>
      </div>
      <LoginDialog isOpen={isLoginDialogOpen} onClose={() => setIsLoginDialogOpen(false)} />
      <UserProfileDialog posts={mockPosts} isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />
    </div>
  )
}

// Main App with Auth Provider
export default function App() {
  return (
    <AuthProvider>
      <SchoolBulletinBoard />
    </AuthProvider>
  )
}

// Shared Utility Functions
const formatTimeAgo = (date: Date) => {
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 1) return "방금 전"
  if (minutes < 60) return `${minutes}분 전`
  if (hours < 24) return `${hours}시간 전`
  return `${days}일 전`
}
