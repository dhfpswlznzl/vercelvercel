// Firestore Security Rules
// Copy these rules to your Firebase Console -> Firestore Database -> Rules

const securityRules = `
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users collection
    match /users/{userId} {
      // Users can read all user profiles
      allow read: if true;
      // Users can only update their own profile
      allow write: if request.auth != null && request.auth.uid == userId;
      // Admins can update any user
      allow write: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
    
    // Posts collection
    match /posts/{postId} {
      // Anyone can read approved posts
      allow read: if resource.data.isApproved == true;
      // Admins can read all posts
      allow read: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
      // Authenticated users can create posts
      allow create: if request.auth != null;
      // Authors and admins can update/delete posts
      allow update, delete: if request.auth != null && 
        (request.auth.uid == resource.data.authorId ||
         (exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
          get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true));
      
      // Comments subcollection
      match /comments/{commentId} {
        // Anyone can read comments on approved posts
        allow read: if get(/databases/$(database)/documents/posts/$(postId)).data.isApproved == true;
        // Authenticated users can create comments
        allow create: if request.auth != null;
        // Authors and admins can update/delete comments
        allow update, delete: if request.auth != null && 
          (request.auth.uid == resource.data.authorId ||
           (exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
            get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true));
      }
    }
  }
}
`

console.log("Firestore Security Rules:")
console.log(securityRules)
console.log("\nCopy the above rules to Firebase Console -> Firestore Database -> Rules")

export { securityRules }
