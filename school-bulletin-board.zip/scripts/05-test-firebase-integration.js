// Comprehensive Firebase Integration Tests
// Run this script to test all Firebase functionality

import { initializeApp } from "firebase/app"
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore"
import {
  getAuth,
  connectAuthEmulator,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth"

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "demo-api-key",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "demo-project.firebaseapp.com",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "demo-project",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "demo-project.appspot.com",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:123456789:web:abcdef",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)
const db = getFirestore(app)
const auth = getAuth(app)

// Connect to emulators in development
if (process.env.NODE_ENV === "development") {
  try {
    connectFirestoreEmulator(db, "localhost", 8080)
    connectAuthEmulator(auth, "http://localhost:9099")
    console.log("✅ Connected to Firebase emulators")
  } catch (error) {
    console.log("ℹ️ Firebase emulators already connected")
  }
}

// Test results tracking
const testResults = {
  passed: 0,
  failed: 0,
  tests: [],
}

function logTest(testName, passed, error = null) {
  const status = passed ? "✅ PASS" : "❌ FAIL"
  console.log(`${status}: ${testName}`)

  if (error) {
    console.log(`   Error: ${error.message}`)
  }

  testResults.tests.push({ name: testName, passed, error })
  if (passed) {
    testResults.passed++
  } else {
    testResults.failed++
  }
}

async function testFirebaseConfiguration() {
  console.log("\n🔧 Testing Firebase Configuration...")

  try {
    // Test Firebase app initialization
    if (app && app.name === "[DEFAULT]") {
      logTest("Firebase app initialization", true)
    } else {
      logTest("Firebase app initialization", false, new Error("App not initialized properly"))
    }

    // Test Firestore connection
    if (db && db.app === app) {
      logTest("Firestore connection", true)
    } else {
      logTest("Firestore connection", false, new Error("Firestore not connected"))
    }

    // Test Auth connection
    if (auth && auth.app === app) {
      logTest("Firebase Auth connection", true)
    } else {
      logTest("Firebase Auth connection", false, new Error("Auth not connected"))
    }
  } catch (error) {
    logTest("Firebase configuration", false, error)
  }
}

async function testAuthentication() {
  console.log("\n🔐 Testing Authentication...")

  const testEmail = `test-${Date.now()}@example.com`
  const testPassword = "testpassword123"

  try {
    // Test user signup
    const userCredential = await createUserWithEmailAndPassword(auth, testEmail, testPassword)
    if (userCredential.user) {
      logTest("User signup", true)
    } else {
      logTest("User signup", false, new Error("No user returned"))
    }

    // Test user logout
    await signOut(auth)
    if (!auth.currentUser) {
      logTest("User logout", true)
    } else {
      logTest("User logout", false, new Error("User still logged in"))
    }

    // Test user login
    const loginCredential = await signInWithEmailAndPassword(auth, testEmail, testPassword)
    if (loginCredential.user) {
      logTest("User login", true)
    } else {
      logTest("User login", false, new Error("Login failed"))
    }

    // Cleanup - logout
    await signOut(auth)
  } catch (error) {
    logTest("Authentication flow", false, error)
  }
}

async function testFirestoreOperations() {
  console.log("\n🗄️ Testing Firestore Operations...")

  try {
    // Import Firebase utilities
    const { createUser, getUserById, updateUser, createPost, getPosts, updatePost, deletePost } = await import(
      "../lib/firebase.ts"
    )

    // Test user creation
    const testUser = {
      id: `test-user-${Date.now()}`,
      name: "Test User",
      email: "test@example.com",
      avatar: "/test-avatar.png",
      bio: "Test bio",
      isAdmin: false,
      followers: [],
      following: [],
      bookmarks: [],
    }

    await createUser(testUser)
    logTest("User creation in Firestore", true)

    // Test user retrieval
    const retrievedUser = await getUserById(testUser.id)
    if (retrievedUser && retrievedUser.name === testUser.name) {
      logTest("User retrieval from Firestore", true)
    } else {
      logTest("User retrieval from Firestore", false, new Error("User data mismatch"))
    }

    // Test user update
    await updateUser(testUser.id, { bio: "Updated bio" })
    const updatedUser = await getUserById(testUser.id)
    if (updatedUser && updatedUser.bio === "Updated bio") {
      logTest("User update in Firestore", true)
    } else {
      logTest("User update in Firestore", false, new Error("Update failed"))
    }

    // Test post creation
    const testPost = {
      title: "Test Post",
      content: "This is a test post",
      authorId: testUser.id,
      category: "free",
      tags: ["test"],
      images: [],
      isPinned: false,
      isAnonymous: false,
      isApproved: true,
      reactions: {},
      views: 0,
    }

    const postRef = await createPost(testPost)
    if (postRef && postRef.id) {
      logTest("Post creation in Firestore", true)

      // Test post retrieval
      const posts = await getPosts()
      const createdPost = posts.find((p) => p.id === postRef.id)
      if (createdPost && createdPost.title === testPost.title) {
        logTest("Post retrieval from Firestore", true)
      } else {
        logTest("Post retrieval from Firestore", false, new Error("Post not found"))
      }

      // Test post update
      await updatePost(postRef.id, { title: "Updated Test Post" })
      const updatedPosts = await getPosts()
      const updatedPost = updatedPosts.find((p) => p.id === postRef.id)
      if (updatedPost && updatedPost.title === "Updated Test Post") {
        logTest("Post update in Firestore", true)
      } else {
        logTest("Post update in Firestore", false, new Error("Post update failed"))
      }

      // Test post deletion
      await deletePost(postRef.id)
      const postsAfterDelete = await getPosts()
      const deletedPost = postsAfterDelete.find((p) => p.id === postRef.id)
      if (!deletedPost) {
        logTest("Post deletion from Firestore", true)
      } else {
        logTest("Post deletion from Firestore", false, new Error("Post still exists"))
      }
    } else {
      logTest("Post creation in Firestore", false, new Error("No post reference returned"))
    }
  } catch (error) {
    logTest("Firestore CRUD operations", false, error)
  }
}

async function testRealtimeListeners() {
  console.log("\n🔄 Testing Real-time Listeners...")

  try {
    const { subscribeToUsers, subscribeToPosts } = await import("../lib/firebase.ts")

    let usersReceived = false
    let postsReceived = false

    // Test users listener
    const unsubscribeUsers = subscribeToUsers((users) => {
      if (Array.isArray(users)) {
        usersReceived = true
        logTest("Users real-time listener", true)
        unsubscribeUsers()
      }
    })

    // Test posts listener
    const unsubscribePosts = subscribeToPosts((posts) => {
      if (Array.isArray(posts)) {
        postsReceived = true
        logTest("Posts real-time listener", true)
        unsubscribePosts()
      }
    })

    // Wait for listeners to receive data
    await new Promise((resolve) => {
      const checkInterval = setInterval(() => {
        if (usersReceived && postsReceived) {
          clearInterval(checkInterval)
          resolve()
        }
      }, 100)

      // Timeout after 5 seconds
      setTimeout(() => {
        clearInterval(checkInterval)
        if (!usersReceived) {
          logTest("Users real-time listener", false, new Error("No data received"))
        }
        if (!postsReceived) {
          logTest("Posts real-time listener", false, new Error("No data received"))
        }
        resolve()
      }, 5000)
    })
  } catch (error) {
    logTest("Real-time listeners setup", false, error)
  }
}

async function testErrorHandling() {
  console.log("\n⚠️ Testing Error Handling...")

  try {
    const { getUserById, updatePost } = await import("../lib/firebase.ts")

    // Test handling of non-existent user
    const nonExistentUser = await getUserById("non-existent-user-id")
    if (nonExistentUser === null) {
      logTest("Non-existent user handling", true)
    } else {
      logTest("Non-existent user handling", false, new Error("Should return null"))
    }

    // Test handling of invalid post update
    try {
      await updatePost("non-existent-post-id", { title: "Updated" })
      logTest("Invalid post update handling", false, new Error("Should have thrown error"))
    } catch (error) {
      logTest("Invalid post update handling", true)
    }
  } catch (error) {
    logTest("Error handling tests", false, error)
  }
}

async function runAllTests() {
  console.log("🚀 Starting Firebase Integration Tests...")
  console.log("=".repeat(50))

  await testFirebaseConfiguration()
  await testAuthentication()
  await testFirestoreOperations()
  await testRealtimeListeners()
  await testErrorHandling()

  console.log("\n" + "=".repeat(50))
  console.log("📊 Test Results Summary:")
  console.log(`✅ Passed: ${testResults.passed}`)
  console.log(`❌ Failed: ${testResults.failed}`)
  console.log(
    `📈 Success Rate: ${((testResults.passed / (testResults.passed + testResults.failed)) * 100).toFixed(1)}%`,
  )

  if (testResults.failed > 0) {
    console.log("\n❌ Failed Tests:")
    testResults.tests
      .filter((test) => !test.passed)
      .forEach((test) => {
        console.log(`   - ${test.name}: ${test.error?.message || "Unknown error"}`)
      })
  }

  console.log("\n🎉 Firebase integration testing complete!")

  return testResults.failed === 0
}

// Run tests if this script is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllTests()
    .then((success) => {
      process.exit(success ? 0 : 1)
    })
    .catch((error) => {
      console.error("Test execution failed:", error)
      process.exit(1)
    })
}

export { runAllTests, testResults }
