// Firestore Composite Indexes
// These indexes need to be created in Firebase Console for optimal performance

const requiredIndexes = [
  {
    collection: "posts",
    fields: [
      { field: "isApproved", order: "ASCENDING" },
      { field: "createdAt", order: "DESCENDING" },
    ],
    description: "For filtering approved posts by creation date",
  },
  {
    collection: "posts",
    fields: [
      { field: "category", order: "ASCENDING" },
      { field: "isApproved", order: "ASCENDING" },
      { field: "createdAt", order: "DESCENDING" },
    ],
    description: "For filtering posts by category and approval status",
  },
  {
    collection: "posts",
    fields: [
      { field: "isPinned", order: "DESCENDING" },
      { field: "createdAt", order: "DESCENDING" },
    ],
    description: "For showing pinned posts first",
  },
  {
    collection: "posts",
    fields: [
      { field: "authorId", order: "ASCENDING" },
      { field: "createdAt", order: "DESCENDING" },
    ],
    description: "For user's own posts",
  },
]

console.log("Required Firestore Composite Indexes:")
console.log("Create these indexes in Firebase Console -> Firestore Database -> Indexes\n")

requiredIndexes.forEach((index, i) => {
  console.log(`${i + 1}. Collection: ${index.collection}`)
  console.log(`   Fields: ${index.fields.map((f) => `${f.field} (${f.order})`).join(", ")}`)
  console.log(`   Description: ${index.description}\n`)
})

export { requiredIndexes }
