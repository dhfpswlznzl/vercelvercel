// Initialize Firestore with sample data
// Run this script to populate the database with initial data

import { initializeApp } from "firebase/app"
import { getFirestore, collection, doc, setDoc, addDoc, serverTimestamp } from "firebase/firestore"

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

async function initializeData() {
  console.log("Initializing Firestore data...")

  // Create sample users
  const users = [
    {
      id: "admin-user-id",
      name: "관리자",
      email: "admin@school.edu",
      avatar: "/admin-interface.png",
      bio: "학교 게시판 관리자입니다.",
      isAdmin: true,
      followers: [],
      following: [],
      bookmarks: [],
    },
    {
      id: "student-1-id",
      name: "김학생",
      email: "student1@school.edu",
      avatar: "/diverse-student-studying.png",
      bio: "컴퓨터공학과 3학년입니다.",
      isAdmin: false,
      followers: [],
      following: [],
      bookmarks: [],
    },
    {
      id: "student-2-id",
      name: "이학생",
      email: "student2@school.edu",
      avatar: "/diverse-students-studying.png",
      bio: "경영학과 2학년입니다.",
      isAdmin: false,
      followers: [],
      following: [],
      bookmarks: [],
    },
  ]

  // Add users to Firestore
  for (const user of users) {
    await setDoc(doc(db, "users", user.id), {
      ...user,
      createdAt: serverTimestamp(),
    })
    console.log(`Created user: ${user.name}`)
  }

  // Create sample posts
  const posts = [
    {
      title: "2024학년도 2학기 수강신청 안내",
      content: "수강신청 일정과 주의사항을 안내드립니다. 자세한 내용은 학사공지를 확인해주세요.",
      authorId: "admin-user-id",
      category: "notice",
      tags: ["수강신청", "학사일정"],
      images: [],
      isPinned: true,
      isAnonymous: false,
      isApproved: true,
      reactions: {
        "👍": ["student-1-id", "student-2-id"],
        "❤️": ["student-1-id"],
      },
      views: 156,
    },
    {
      title: "스터디 그룹 모집합니다",
      content: "알고리즘 스터디 그룹을 모집합니다. 매주 화요일 저녁에 진행할 예정입니다.",
      authorId: "student-1-id",
      category: "study",
      tags: ["알고리즘", "스터디", "모집"],
      images: [],
      isPinned: false,
      isAnonymous: false,
      isApproved: true,
      reactions: {
        "👍": ["admin-user-id", "student-2-id"],
        "🎉": ["student-2-id"],
      },
      views: 89,
    },
    {
      title: "익명 질문입니다",
      content: "학점 관련해서 궁금한 점이 있는데 익명으로 질문드립니다.",
      authorId: "student-2-id",
      category: "anonymous",
      tags: ["질문", "학점"],
      images: [],
      isPinned: false,
      isAnonymous: true,
      isApproved: false,
      reactions: {
        "🤔": ["admin-user-id"],
      },
      views: 45,
    },
  ]

  // Add posts to Firestore
  for (const post of posts) {
    const postRef = await addDoc(collection(db, "posts"), {
      ...post,
      createdAt: serverTimestamp(),
    })
    console.log(`Created post: ${post.title} (ID: ${postRef.id})`)

    // Add sample comment to first post
    if (post.title.includes("수강신청")) {
      await addDoc(collection(db, "posts", postRef.id, "comments"), {
        content: "감사합니다!",
        authorId: "student-1-id",
        isAnonymous: false,
        createdAt: serverTimestamp(),
      })
      console.log(`Added comment to post: ${post.title}`)
    }
  }

  console.log("Firestore initialization complete!")
}

// Run initialization
initializeData().catch(console.error)
