-- Firestore Collections Structure for School Bulletin Board
-- This script documents the Firestore collections and their structure

-- Users Collection: /users/{userId}
-- Document structure:
-- {
--   id: string (document ID matches Firebase Auth UID)
--   name: string
--   email: string  
--   avatar: string (URL)
--   bio: string
--   isAdmin: boolean
--   followers: array of user IDs
--   following: array of user IDs
--   bookmarks: array of post IDs
--   createdAt: timestamp
--   updatedAt: timestamp
-- }

-- Posts Collection: /posts/{postId}
-- Document structure:
-- {
--   id: string (auto-generated document ID)
--   title: string
--   content: string
--   authorId: string (reference to user ID)
--   category: string (notice|free|anonymous|qna|study)
--   tags: array of strings
--   images: array of image URLs
--   createdAt: timestamp
--   updatedAt: timestamp
--   isPinned: boolean
--   isAnonymous: boolean
--   isApproved: boolean
--   reactions: map of {emoji: array of user IDs}
--   views: number
-- }

-- Comments Collection: /posts/{postId}/comments/{commentId}
-- Subcollection under posts
-- Document structure:
-- {
--   id: string (auto-generated document ID)
--   content: string
--   authorId: string (reference to user ID)
--   createdAt: timestamp
--   isAnonymous: boolean
-- }

-- Indexes needed:
-- Posts: createdAt (descending) - for chronological listing
-- Posts: category, createdAt (descending) - for category filtering
-- Posts: isApproved, createdAt (descending) - for approved posts
-- Posts: isPinned, createdAt (descending) - for pinned posts
-- Comments: createdAt (ascending) - for comment ordering

SELECT 'Firestore collections structure documented' as status;
